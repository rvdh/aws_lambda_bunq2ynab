#!/bin/bash

echo Removing BUNQ state files...
rm private_key.txt installation_token.txt server_public.txt session_token.txt
