#!/bin/bash
zip -r ../bunq2ynab.zip . -x .git/\* \*pyc 
